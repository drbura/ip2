<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - Student Clearance Management System</title>

</head>
<body>
  <?php include '../admin/lib.php' ?>
  <?php include '../admin/header.php' ?>

  <?php include 'user_data.php' ?>

  <?php include '../admin/footer.php' ?>

</body>
</html>